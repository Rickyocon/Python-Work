from minime import *;
def decoOne():
	width = 10;
	for x in range(0, 50):
		drawCircle(0, 0, x*5);
decoOne();
input();
