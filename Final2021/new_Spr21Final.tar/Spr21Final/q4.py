# Your job below
# Decode encoded.txt
#--------------------------------------
import encode *;

f1 = open("encode.txt", "r");
s1 = f1.readlines();
f1.close();


