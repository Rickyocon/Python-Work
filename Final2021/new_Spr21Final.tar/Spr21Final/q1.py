n = int(input("Enter n: "));

#--------------------------------------
#Your job below! (estimate: 5 lines of code)
#--------------------------------------
for x in range(n):
	if x**0.5%1==0:
		print(x);
	
