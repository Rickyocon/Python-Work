n = int(input("Enter n: "));

# Your job below (around 30 lines)
# -----------------------------------------------

