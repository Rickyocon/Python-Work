n = int(input("Enter n: "));

#--------------------------------------
#Your job below! (estimate: 5 lines of code)
#--------------------------------------
