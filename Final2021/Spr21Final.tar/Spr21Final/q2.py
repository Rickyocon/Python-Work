def findLargestEven(filename):
	# ------- YOUR JOB BELOW -----------------
	return -1;

# main program
arr = ["n1.txt", "n2.txt", "n3.txt", "n4.txt", "n5.txt"];
for file in arr:
	num = findLargestEven(file);
	print(file + ": " + str(num));

