# Your job below
# Decode encoded.txt
#--------------------------------------------


