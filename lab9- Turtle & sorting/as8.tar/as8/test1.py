from arrOps import *;

for x in range(20):	
	drawRectangle(x*10, x*5, "#000000");
input("Enter to complete.");
