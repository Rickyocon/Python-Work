from arrOps import *;

arr = [1, 1, 1, 1, 1, 1, 1];
idx = 0;
while idx<len(arr):
	setArrElement(arr, idx, idx*50);
	idx = idx + 1;
input("Enter to complete.");
	
