# return the LAST LONGEST word in the file
def getLastLongestWord(filename):
    # ------------------------
    # Your Job Here
    # ------------------------

# ---------------------------------
# MAIN PROGRAM. Do not touch
# ---------------------------------
arr = ["Yankee", "HardTime", "GreatExpectation"];
for fname in arr:
    word= getLastLongestWord(fname);
    print(fname + ": " + word);
