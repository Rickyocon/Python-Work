def drawPyramid(n):
#----------------------
# Your Job Below
#----------------------


# ---------------------------
# Main Program. Do not touch 
# ---------------------------
n = int(input("Enter n: "));
drawPyramid(n);
input();
